%% TaylorRule Apply the taylor rule.
%   This function chooses a Taylor rule control.
%
%   u = TAYLORRULE(x, constraint_set, delta_fn, controlmax)
%
% See also: CONTROLALGS/MAXIMUMCONTROL, CONTROLALGS/MINIMUMCONTROL
function u = TaylorRule(x, K, delta_fn, c, varargin)    

    % State values are stored in the vector x.  We only take the first
    % three so that this algorithm works in both 3D and 4D.
    y = x(1); pi = x(2); i = x(3);
    
    % Targets.  In steady state pi = i, so they should be the same. y_T = 0
    % because y represents the output gap.
    pi_T = 0.02;
    i_T = 0.02;
    y_T = 0;

    % Note that we subtract i, because u = idot \approx i_desired - i
    u = (i_T - i) + 1.5*(pi - pi_T) + 0.5*(y - y_T); 
    
    % Comment out the below lines if you don't want the taylor rule to be
    % limited to [-c, c]
    if (u > c)
        u = c;
    elseif (u < -c)
        u = -c;
    end
end