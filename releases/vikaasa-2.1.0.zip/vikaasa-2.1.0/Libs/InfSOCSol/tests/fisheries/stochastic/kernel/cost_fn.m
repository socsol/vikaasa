function cost = cost_fn(u,x,t,conf)
  b = x(1);
  e = x(2);
  
  cost = u^2;
end
