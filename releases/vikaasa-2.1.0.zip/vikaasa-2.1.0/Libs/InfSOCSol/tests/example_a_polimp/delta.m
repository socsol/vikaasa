function v = delta(u,x,t)
v = u;
