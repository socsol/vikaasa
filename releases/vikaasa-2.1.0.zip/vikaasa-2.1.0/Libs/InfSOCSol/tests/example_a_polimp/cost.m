function v = cost(u,x,varargin)
v = (u^2 + x^2) / 2;
