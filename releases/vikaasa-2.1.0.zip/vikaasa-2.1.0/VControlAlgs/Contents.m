% VCONTROLALGS
%
% Files
%   Satisfice - Satisficing Viabilty Control Algorithm
